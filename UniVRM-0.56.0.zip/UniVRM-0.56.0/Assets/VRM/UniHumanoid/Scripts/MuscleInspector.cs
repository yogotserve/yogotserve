﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace UniHumanoid
{
    public class MuscleInspector : MonoBehaviour
    {
    }
}
