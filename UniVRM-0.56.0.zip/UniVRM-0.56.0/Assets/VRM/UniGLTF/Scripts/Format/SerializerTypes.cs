﻿namespace UniGLTF
{
    public enum SerializerTypes
    {
        JsonSerializable, // manual, Obsolete
        UniJSON, // reflection
        Generated, // generated, experimental for mobile
    }
}
