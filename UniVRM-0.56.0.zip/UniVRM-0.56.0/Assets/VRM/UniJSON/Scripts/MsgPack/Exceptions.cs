using System;

namespace UniJSON
{

    public class MsgPackTypeException : Exception
    {
        public MsgPackTypeException(string msg) : base(msg)
        { }

    }

}