namespace VRM
{
    public static class SkinnedMeshUtility
    {
        public const string MENU_KEY = "GameObject/UnityEditorScripts/";
        public const int MENU_PRIORITY = 11;
    }
}