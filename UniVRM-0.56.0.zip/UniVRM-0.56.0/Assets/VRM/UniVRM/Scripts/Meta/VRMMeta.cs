﻿using UnityEngine;


namespace VRM
{
    public class VRMMeta : MonoBehaviour
    {
        [SerializeField]
        public VRMMetaObject Meta;
    }
}
