
namespace VRM
{
    public static partial class VRMVersion
    {
        public const int MAJOR = 0;
        public const int MINOR = 56;
        public const int PATCH = 0;
        public const string PRE_ID = "";

        public const string VERSION = "0.56.0";
    }
}
