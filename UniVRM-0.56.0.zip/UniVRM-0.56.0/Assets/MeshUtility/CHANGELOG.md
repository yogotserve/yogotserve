# Changelog
All notable changes to this package will be documented in this file.

## [0.0.1] - 2020-07-01
### Added
- The first release of MeshUtility
- Add MeshSeparator: the mesh with BlendShape can be separated out