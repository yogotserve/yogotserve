# MeshUtility

A mesh processing package for mesh separation, etc.

## Documentation Link

[MeshSeparator](https://github.com/vrm-c/UniVRM/tree/master/Assets/MeshUtility/Documentation/notes/MeshSeparator.md)