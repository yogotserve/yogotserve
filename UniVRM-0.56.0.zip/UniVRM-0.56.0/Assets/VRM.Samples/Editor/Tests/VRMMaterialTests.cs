﻿using NUnit.Framework;
using UnityEngine;


namespace VRM.Samples
{
    public class VRMMaterialTests
    {
        /*
        [Test]
        public void ExportTest()
        {
            {
                var material = Resources.Load<Material>("Materials/vrm_unlit_texture");
                var exporter = new VRMMaterialExporter();
                var exported = exporter.ExportMaterial(material, null);
                Assert.NotNull(exported.extensions.KHR_materials_unlit);
                Assert.AreEqual("OPAQUE", exported.alphaMode);
            }
            {
                var material = Resources.Load<Material>("Materials/vrm_unlit_transparent");
                var exporter = new VRMMaterialExporter();
                var exported = exporter.ExportMaterial(material, null);
                Assert.NotNull(exported.extensions.KHR_materials_unlit);
                Assert.AreEqual("BLEND", exported.alphaMode);
            }
            {
                var material = Resources.Load<Material>("Materials/vrm_unlit_cutout");
                var exporter = new VRMMaterialExporter();
                var exported = exporter.ExportMaterial(material, null);
                Assert.NotNull(exported.extensions.KHR_materials_unlit);
                Assert.AreEqual("MASK", exported.alphaMode);
            }
            {
                var material = Resources.Load<Material>("Materials/vrm_unlit_transparent_zwrite");
                var exporter = new VRMMaterialExporter();
                var exported = exporter.ExportMaterial(material, null);
                Assert.NotNull(exported.extensions.KHR_materials_unlit);
                Assert.AreEqual("BLEND", exported.alphaMode);
            }
            {
                var material = Resources.Load<Material>("Materials/mtoon_opaque");
                var exporter = new VRMMaterialExporter();
                var exported = exporter.ExportMaterial(material, null);
                Assert.NotNull(exported.extensions.KHR_materials_unlit);
                Assert.AreEqual("OPAQUE", exported.alphaMode);
            }
            {
                var material = Resources.Load<Material>("Materials/mtoon_transparent");
                var exporter = new VRMMaterialExporter();
                var exported = exporter.ExportMaterial(material, null);
                Assert.NotNull(exported.extensions.KHR_materials_unlit);
                Assert.AreEqual("BLEND", exported.alphaMode);
            }
            {
                var material = Resources.Load<Material>("Materials/mtoon_cutout");
                var exporter = new VRMMaterialExporter();
                var exported = exporter.ExportMaterial(material, null);
                Assert.NotNull(exported.extensions.KHR_materials_unlit);
                Assert.AreEqual("MASK", exported.alphaMode);
            }
            {
                var material = Resources.Load<Material>("Materials/mtoon_culloff");
                var exporter = new VRMMaterialExporter();
                var exported = exporter.ExportMaterial(material, null);
                Assert.NotNull(exported.extensions.KHR_materials_unlit);
                Assert.True(exported.doubleSided);
            }
        }
    */
    }
}
